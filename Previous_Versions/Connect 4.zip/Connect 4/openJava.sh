#!/bin/bash
cd "$(dirname "$0")"
java -jar CompSci_Prj*.jar